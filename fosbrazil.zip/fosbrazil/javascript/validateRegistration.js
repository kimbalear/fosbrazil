define(['jquery'], function($) {
  return {
      validate: function() {
          console.log('validateRegistration.js Archivo cargado correctamente.');
      }
  };
});
