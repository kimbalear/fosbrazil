require(["jquery"], function ($) {
  $(document).ready(function () {
  });
});
