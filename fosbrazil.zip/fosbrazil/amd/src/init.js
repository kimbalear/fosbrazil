export const init = () => {
    document.getElementById("fitem_id_profile_field_occupation_other").style.display = "none";
    document.getElementById("fitem_id_profile_field_gender_other").style.display = "none";
    document.getElementById("fitem_id_city").style.display = "none";
    document.getElementById("fitem_id_country").style.display = "none";
};