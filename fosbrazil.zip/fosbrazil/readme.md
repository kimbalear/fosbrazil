# pix/icons
´<img src="/theme/image.php/fosbrazil/theme_fosbrazil/1702559881/icons/image1" />´

