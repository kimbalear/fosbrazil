sass --watch style/custom.scss:style/custom.css

/pluginfile.php/26/course/overviewfiles/1.jpg