sass --watch style/custom.scss:style/custom.css

/pluginfile.php/26/course/overviewfiles/1.jpg

.lg_cnt div[role=main] .d-flex {
    flex-direction: row !important;
    align-items: stretch;
}